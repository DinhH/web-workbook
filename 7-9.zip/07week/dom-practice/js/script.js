'use strict';

window.onload = function(){
//these are all the functions that run at the beginning
  itemAlert();
  insertItemCounter();
  insertAddItem();
  insertRemoveItemExistingItems();
}

function listCount(){
  let list = document.getElementsByTagName("ul");
  return list[0].children.length;
}

//does the cart count pop up
function itemAlert () {
  let list = document.getElementsByTagName("ul");
  alert("there are " + listCount() + " items in your shopping cart");
}

//creates and inserts the h2 item counter.
function insertItemCounter () {
  let newh2 = document.createElement('h2');
  let list = document.getElementsByTagName("ul");
  let listCount = list[0].children.length;
  newh2.innerHTML = 'You have ' + listCount + ' items in your shopping cart';
  let countMessage = document.getElementsByTagName("h1");
  countMessage[0].after(newh2);
  newh2.setAttribute("id", "item-count")
}

//creates the add item form and button

function insertAddItem () {
  //text area
  var newInput = document.createElement('input');
  newInput.setAttribute("placeholder", "Type to add");
  let cart = document.getElementsByTagName("ul");
  cart[0].after(newInput);
  newInput.setAttribute("id", "input-text");


  let newButton = document.createElement('button');
  newButton.innerHTML = 'Add Items';
  newButton.setAttribute("id", "add-button")
  let nextButton = document.getElementsByTagName("input");
  nextButton[0].after(newButton);

  newButton.onclick = addItem;
}

//this is the function that adds the items.
function addItem(event){
  let newItemText = document.getElementById("input-text");
  let newItem = document.createElement("li");
  newItem.innerHTML= newItemText.value;
  //string of user input
  document.getElementsByTagName("ul")[0].appendChild(newItem);
  document.getElementById('input-text').value='';
  insertRemoveItem(newItem);
  updateItemCounter();
}

//updates the item counter when an item is added or removed
function updateItemCounter(){
  let h2 = document.getElementById("item-count");
  h2.innerHTML = 'You have ' + document.getElementsByTagName('ul')[0].children.length + ' items in your shopping cart';
}

//creates the actual remove button
function insertRemoveItem (items) {
  let removeButton= document.createElement('button');
  removeButton.innerHTML = "Remove";
    items.appendChild(removeButton);
  removeButton.onclick = eraseItem;
}

function addrembuttonstoexistingitems() {
let cartstuff = document.querySelectorAll('li');
for (let i = 0; i < cartstuff.length; i++) {
  let cartitems = document.getElementById('shoppingCart').getElementsByTagName("li")[i];
  let rembutton = document.createElement('button');
  rembutton.type = "button";
  rembutton.setAttribute("id", "remove-button");
  rembutton.innerHTML="Remove";
  cartitems.appendChild(rembutton);
  rembutton.onclick = deleteItem;

  function deleteItem() {
    this.parentNode.remove(this);
    updatecartcounter();
    }
  }
}

//removes the things
function eraseItem(){
  this.parentNode.remove();
  updateItemCounter();
}

//puts the remove button on the itesm that are already there!
function insertRemoveItemExistingItems(){
  let cart = document.getElementById("cart");
  for (let i = 0; i < cart.children.length; i++){
  insertRemoveItem(cart.children[i]);
}
}

// 'use strict';
//
// // JOB 4 Create the ability to remove an item from the shopping cart using javascript.
// // JOB 5 Extension Challenge: Create the ability to display a picture of the product when the mouse hovers over the name of the project.
// document.addEventListener("DOMContentLoaded", function(event) {
//   //creates a list of the items in the cart
//
//
//   let list = document.getElementsByTagName('ul');
//   var shoppingList = document.getElementsByTagName('ul')[0];
//   document.getElementsByTagName("ul")[0].setAttribute("id", "shoppingCart");
//
//   //JOB 1, the alert
//   let message = "This page has " + shoppingList.children.length + " list items my dude";
//   alert(message);
//
//   //JOB 2
//   //creates the h2 that will be inserted as the h1's child
//   let cartcounter = document.createElement('h2');
//   //adss html inside that h2 we just created
//
//   updatecartcounter();
//
//
//     function updatecartcounter() {
//     cartcounter.innerHTML = "You have " + shoppingList.children.length + " items in your shopping cart, my dude";
//     }
//
//   //finds the h1 that we want the newh2 to go under, then we append it underneath
//   document.getElementsByTagName('h1')[0].appendChild(cartcounter);
//
//
//   //creates a text field
//   let input_txt = document.createElement('input');
//   input_txt.setAttribute("id", "item-text");
//   input_txt.type = "text";
//   document.getElementsByTagName('h1')[0].appendChild(input_txt);
//   //creates "Add item" button next to text field
//   let input_btn = document.createElement('button');
//   input_btn.type = "button";
//   input_btn.setAttribute("id", "item-button");
//   input_btn.innerHTML="Add Item";
//   document.getElementsByTagName('h1')[0].appendChild(input_btn);
//
//   //JOB 3,4 Takes input from text field and adds it to a new li in the ul, then adds remove button
//   input_btn.onclick = addLi;
//
//
//
//   function addLi() {
//     //creates the li
//     let li = document.createElement("li");
//     //grabs the text written in the field, calls it newItem
//     let newItem = document.getElementById('item-text').value;
//     //puts newItem into the li
//     li.innerHTML = newItem;
//     //appends it to shoppingList
//     shoppingList.appendChild(li);
//
//     //creating remove button
//
//     addrembutton();
//
//     function addrembutton() {
//       let rembutton =  document.createElement('button');
//       rembutton.type = "button";
//       rembutton.setAttribute("id", "remove-button");
//       rembutton.innerHTML="Remove";
//       li.appendChild(rembutton);
//       rembutton.onclick = deleteItem;
//
//       function deleteItem() {
//         this.parentNode.remove(this);
//         updatecartcounter();
//         }
//       updatecartcounter();
//     }
//
//   }
//
//     addrembuttonstoexistingitems();
//
//   function addrembuttonstoexistingitems() {
//   let cartstuff = document.querySelectorAll('li');
//   for (let i = 0; i < cartstuff.length; i++) {
//     let cartitems = document.getElementById('shoppingCart').getElementsByTagName("li")[i];
//     let rembutton = document.createElement('button');
//     rembutton.type = "button";
//     rembutton.setAttribute("id", "remove-button");
//     rembutton.innerHTML="Remove";
//     cartitems.appendChild(rembutton);
//     rembutton.onclick = deleteItem;
//
//     function deleteItem() {
//       this.parentNode.remove(this);
//       updatecartcounter();
//       }
//     }
//   }
// });
