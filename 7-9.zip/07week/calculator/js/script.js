'use strict';

document.addEventListener("DOMContentLoaded", function(event) {
  // You code here
});
